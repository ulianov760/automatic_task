<?php

namespace App\Models;

use Backpack\CRUD\app\Models\Traits\CrudTrait;
use Goat1000\SVGGraph\SVGGraph;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\DB;

class Settlement extends Model
{
    use CrudTrait;
    use HasFactory;

    protected $fillable = [
        'id',
        'name',
        'date_create',
        'date_finish',
        'type_transaction_id',
        'employee_id',
        'status_id',
        'company_id',
        'sum',
    ];

    public $timestamps = false;

    public static function getReport($startDate,$endDate){
        $reportData = Settlement::query()
            ->join('companies', 'settlements.company_id', '=', 'companies.id')
            ->join('type_transactions', 'settlements.type_transaction_id', '=', 'type_transactions.id')
            ->select(
                'companies.name as company_name',
                'type_transactions.name as status_name',
                'type_transactions.id as status_id',
                DB::raw('SUM(settlements.sum) as total_sum')
            )
            ->whereBetween('settlements.date_create', [$startDate, $endDate])
            ->groupBy('companies.id', 'companies.name', 'type_transactions.id', 'type_transactions.name')
            ->orderBy('companies.name')
            ->get();

             return [$reportData->sum('total_sum'),$reportData];
    }

    public static function formedChartData($data){
       return $data->groupBy('company_name')->map(function ($items, $companyName) {
           return [
               'company' => $companyName,
               'operations' => $items->map(function($item) {
                   return [
                       'name' => $item->status_name,
                       'sum' => $item->total_sum,
                       'id' => $item->status_id,
                   ];
               })
           ];
       })->toArray();
    }

    public static function generateCh($chartData){
        $totalIncome = 0;
        $totalExpense = 0;

        foreach ($chartData as $group) {
            $totalIncome += (float)(collect($group['operations'])->firstWhere('id', 2)['sum'] ?? 0);
            $totalExpense += (float)(collect($group['operations'])->firstWhere('id', 3)['sum'] ?? 0);
        }


        $dataValues = [
            'Поступления' => $totalIncome,
            'Отчисления'  => $totalExpense
        ];

        $settings = [
            'auto_rescale'    => true,
            'back_colour'     => '#ffffff',
            'dataset_colours' => ['#0000FF', '#CC0000'],
            'axis_font'       => 'Arial',
            'axis_font_size'  => 12,


            'show_labels'     => true,
            'label_font_size' => 14,
            'label_font_weight' => 'bold',
            'label_colour'    => '#fff',
            'inner_radius'    => 0.5,
        ];

        $graph = new \Goat1000\SVGGraph\SVGGraph(600, 400, $settings);
        $graph->values($dataValues);

        $svg = $graph->fetch('PieGraph');

        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }

    public function employee(): BelongsTo
    {
        return $this->belongsTo(Employee::class);
    }

    public function status(): BelongsTo
    {
        return $this->belongsTo(PaymentStatus::class);
    }

    public function company(): BelongsTo
    {
        return $this->belongsTo(Company::class);
    }

    public function transaction(): BelongsTo
    {
        return $this->belongsTo(TypeTransaction::class);
    }

    public function setDatetimeAttribute($value) {
        $this->attributes['datetime'] = \Carbon\Carbon::parse($value);
    }
}
