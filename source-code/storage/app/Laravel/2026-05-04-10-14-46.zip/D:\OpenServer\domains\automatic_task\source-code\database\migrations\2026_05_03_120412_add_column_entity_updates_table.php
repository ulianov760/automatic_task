<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('entity_updates', function (Blueprint $table) {
            $table->string('type')->nullable();
            $table->string('move')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('entity_updates', function (Blueprint $table) {
            $table->dropColumn('type');
            $table->dropColumn('move');
        });
    }
};
