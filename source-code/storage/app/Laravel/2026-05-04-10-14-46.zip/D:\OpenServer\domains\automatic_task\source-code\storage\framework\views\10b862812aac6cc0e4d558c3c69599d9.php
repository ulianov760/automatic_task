<li class="nav-item">
    <a <?php echo e($attributes->merge(['class' => 'nav-link', 'href' => $link])); ?>>
        <?php if($icon != null): ?><i class="nav-icon <?php echo e($icon); ?>"></i><?php endif; ?>
        <?php if($title != null): ?><span><?php echo e($title); ?></span><?php endif; ?>
    </a>
</li>
<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\vendor/backpack/theme-coreuiv4/resources/views/components/menu-item.blade.php ENDPATH**/ ?>