<?php echo e($slot); ?>

<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>