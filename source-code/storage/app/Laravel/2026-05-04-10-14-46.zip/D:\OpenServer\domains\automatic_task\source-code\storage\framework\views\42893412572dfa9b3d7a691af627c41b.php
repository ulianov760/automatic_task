<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>

        * {
            font-family: "DejaVu Sans", sans-serif !important;
        }
        @page { margin: 120px 50px 50px 50px; }
        header {
            position: fixed;
            top: -100px;
            left: 0;
            right: 0;
            height: 100px;
            text-align: right;
            font-size: 10px;
            border-bottom: 1px solid #ccc;
            font-family: 'DejaVu Sans', sans-serif;
        }
        body {
            font-family: 'DejaVu Sans', sans-serif;
            font-size: 12px;
        }
        .content { font-family: 'DejaVu Sans', sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; page-break-after: auto;}
        th, td { border: 1px solid #000; padding: 5px; text-align: left; }
        .total-row { font-weight: bold; background: #eee; }
        .row-view-item { margin-bottom: 10px; border-bottom: 1px dashed #ccc; padding: 5px; }
        table, div, p {
            font-family: 'DejaVu Sans', sans-serif;
        }
        thead {
            display: table-header-group;
        }

        tr {
            page-break-inside: avoid;
        }

    </style>
</head>
<body>

<header>

    <div>Общество с ограниченной ответственностью «П-Сейлс»</div>
    <div>НИЖЕГОРОДСКАЯ УЛ, Д. 11, КОМ. 3, НИЖНИЙ НОВГОРОД, РОССИЯ, 603000</div>
    <div>ОГРНИП / ИНН 5257169600</div>
</header>

<div class="content">
    <h3>Отчет за период с <?php echo e($startDate); ?> по <?php echo e($endDate); ?></h3>

<?php if($view == 1): ?>
        <table>
            <thead>
            <?php if($type == 1): ?>
                <tr><th>ФИО</th><th>Количество задач</th></tr>
                <?php elseif($type == 3): ?>
                    <tr>
                        <th>ФИО сотрудника</th>
                        <th>Количество дней отпуска</th>
                    </tr>
                <?php else: ?>
                <tr><th>Компания</th><th>Статус</th><th>Сумма</th></tr>
            <?php endif; ?>
            </thead>
            <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($type == 1): ?>
                        <td><?php echo e($item->fio); ?></td>
                        <td><?php echo e($item->executor_task_count); ?></td>
                        <?php elseif($type == 3): ?>
                            <td><?php echo e($item->fio); ?></td>
                            <td><?php echo e($item->total_days); ?></td>
                    <?php else: ?>
                        <td><?php echo e($item->company_name); ?></td>
                        <td><?php echo e($item->status_name); ?></td>
                        <td><?php echo e(number_format($item->total_sum, 2)); ?></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr class="total-row">
                <td>ИТОГО:</td>
                <?php if($type == 1): ?>
                    <td><?php echo e($total); ?></td>
                    <?php elseif($type == 3): ?>
                        <td><?php echo e($total); ?></td>
                <?php else: ?>
                    <td></td><td><?php echo e(number_format($total, 2)); ?></td>
                <?php endif; ?>
            </tr>
            </tfoot>
        </table>
    <?php elseif($view == 3): ?>
        <div style="text-align: center; margin-top: 20px;">
            <img src="<?php echo e($chatBase64); ?>" style="width: 100%; height: auto;">
        </div>
<?php else: ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row-view-item">
                <?php if($type == 1): ?>
                    <strong><?php echo e($item->fio); ?></strong>: <?php echo e($item->executor_task_count); ?> задач.
                    <?php elseif($type == 3): ?>
                        <strong><?php echo e($item->fio); ?></strong>: <?php echo e($item->total_days); ?> дн.
                <?php else: ?>
                    <strong><?php echo e($item->company_name); ?></strong> (<?php echo e($item->status_name); ?>): <?php echo e(number_format($item->total_sum, 2)); ?> руб.
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <hr>
                <div style="page-break-inside: avoid;">
                    <hr>
                    <div class="total-row">
                        ОБЩИЙ ИТОГ: <?php echo e($type == 2 ? number_format($total, 2) . ' руб.' : $total . ($type == 3 ? ' дн.' : '')); ?>

                    </div>
                </div>
    <?php endif; ?>
</div>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\resources\views/reports/pdf_template.blade.php ENDPATH**/ ?>