<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>