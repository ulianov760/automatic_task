<div class="float-right mr-2">
    <a href="javascript:void(0)"
       class="btn btn-outline-secondary btn-sm"
       data-bs-toggle="popover"
       data-bs-trigger="hover focus"
       data-bs-placement="bottom"
       title="Справка по разделу"
       data-bs-content="
       Для того чтобы создать задачу: 1) Нажмите кнопку 'Добавить задачу' 2) Заполните обязательные поля, обозначенные звездочкой 3) Нажмите кнопку 'Сохранить и выйти'
Для редактирования: 1) В списке задач, рядом с нужной задачей нажмите на кнопку 'Редактировать' 2) В открывшемся окне отредактируйте задачу 3) Нажмите кнопку 'Сохранить и выйти'
Для удаления: В списке задач, рядом с нужной задачей нажмите на кнопку 'Удалить' и потвердите действие">
        <i class="la la-question-circle"></i> Справка
    </a>
</div>
<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\resources\views/vendor/backpack/ui/widgets/help_button.blade.php ENDPATH**/ ?>