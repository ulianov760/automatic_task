<?php $helper = app('Backpack\LanguageSwitcher\Helpers\LanguageSwitcherHelper'); ?>

<li class="nav-item me-2 dropdown language-switcher">
    <a class="nav-link dropdown-toggle text-decoration-none" data-bs-toggle="dropdown" data-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false" style="cursor: pointer">
        <?php if($flags ?? true): ?>
        <span class="nav-link-icon" style="width: fit-content">
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'flag-'.e($helper->getFlagOrFallback($helper->getCurrentLocale())).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 1.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        </span>
        <?php endif; ?>
        <?php if($main_label ?? false || (($flags ?? true) === false && !isset($main_label))): ?>
        <span class="nav-link-title">
            <?php echo e(is_string($main_label ?? false) ? $main_label : $helper->getLocaleName($helper->getCurrentLocale())); ?>

        </span>
        <?php endif; ?>
    </a>
    <ul class="dropdown-menu dropdown-menu-right dropdown-menu-end" style="right: 0">
        <?php
            $useAdminPrefix = config('backpack.language-switcher.use_backpack_route_prefix');
        ?>
        <?php $__currentLoopData = config('backpack.crud.locales', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <a class="dropdown-item <?php echo e($locale === $helper->getCurrentLocale() ? 'active disabled' : ''); ?>" href="<?php echo e(route('language-switcher.locale', [
                    'locale' => $useAdminPrefix ? $locale : null, 
                    'backpack_prefix' => $useAdminPrefix ? config('backpack.base.route_prefix') : 'set-locale',
                    'setLocale' => $useAdminPrefix ? 'set-locale' : $locale
                ])); ?>">
                <?php if($flags ?? true): ?>
                <span class="nav-link-icon" style="width: fit-content">
                    <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'flag-'.e($helper->getFlagOrFallback($locale)).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 1.5rem']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
                </span>
                <?php endif; ?>
                <span class="nav-link-title">
                    <?php echo e($name); ?>

                </span>
            </a>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</li>
<?php /**PATH D:\OpenServer\domains\automatic_task\source-code\vendor\backpack\language-switcher\src/../resources/views/language-switcher.blade.php ENDPATH**/ ?>