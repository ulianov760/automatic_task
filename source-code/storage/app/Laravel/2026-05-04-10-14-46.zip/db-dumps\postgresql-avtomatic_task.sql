--
-- PostgreSQL database dump
--

-- Dumped from database version 12.7
-- Dumped by pg_dump version 12.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache OWNER TO avtomatic_task;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration integer NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO avtomatic_task;

--
-- Name: companies; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.companies (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.companies OWNER TO avtomatic_task;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.companies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO avtomatic_task;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: employee_groups; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.employee_groups (
    id bigint NOT NULL,
    employee_id bigint NOT NULL,
    group_id bigint NOT NULL
);


ALTER TABLE public.employee_groups OWNER TO avtomatic_task;

--
-- Name: employee_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.employee_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_groups_id_seq OWNER TO avtomatic_task;

--
-- Name: employee_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.employee_groups_id_seq OWNED BY public.employee_groups.id;


--
-- Name: employee_roles; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.employee_roles (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    employee_id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.employee_roles OWNER TO avtomatic_task;

--
-- Name: employee_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.employee_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employee_roles_id_seq OWNER TO avtomatic_task;

--
-- Name: employee_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.employee_roles_id_seq OWNED BY public.employee_roles.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.employees (
    id bigint NOT NULL,
    fio character varying(255),
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    age integer,
    sex character(5),
    team_id bigint DEFAULT '1'::bigint NOT NULL,
    post_id bigint DEFAULT '1'::bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100)
);


ALTER TABLE public.employees OWNER TO avtomatic_task;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.employees_id_seq OWNER TO avtomatic_task;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: entity_updates; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.entity_updates (
    id bigint NOT NULL,
    fio character varying(255) NOT NULL,
    name text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    type character varying(255),
    move character varying(255)
);


ALTER TABLE public.entity_updates OWNER TO avtomatic_task;

--
-- Name: entity_updates_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.entity_updates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.entity_updates_id_seq OWNER TO avtomatic_task;

--
-- Name: entity_updates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.entity_updates_id_seq OWNED BY public.entity_updates.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO avtomatic_task;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO avtomatic_task;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.groups OWNER TO avtomatic_task;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_id_seq OWNER TO avtomatic_task;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs integer NOT NULL,
    pending_jobs integer NOT NULL,
    failed_jobs integer NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at integer,
    created_at integer NOT NULL,
    finished_at integer
);


ALTER TABLE public.job_batches OWNER TO avtomatic_task;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at integer,
    available_at integer NOT NULL,
    created_at integer NOT NULL
);


ALTER TABLE public.jobs OWNER TO avtomatic_task;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO avtomatic_task;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO avtomatic_task;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO avtomatic_task;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO avtomatic_task;

--
-- Name: payment_statuses; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.payment_statuses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.payment_statuses OWNER TO avtomatic_task;

--
-- Name: payment_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.payment_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_statuses_id_seq OWNER TO avtomatic_task;

--
-- Name: payment_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.payment_statuses_id_seq OWNED BY public.payment_statuses.id;


--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO avtomatic_task;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO avtomatic_task;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.posts (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.posts OWNER TO avtomatic_task;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.posts_id_seq OWNER TO avtomatic_task;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: priorities; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.priorities (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.priorities OWNER TO avtomatic_task;

--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.priorities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.priorities_id_seq OWNER TO avtomatic_task;

--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.priorities_id_seq OWNED BY public.priorities.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.roles OWNER TO avtomatic_task;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO avtomatic_task;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO avtomatic_task;

--
-- Name: settlements; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.settlements (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    date_create timestamp(0) without time zone NOT NULL,
    sum double precision NOT NULL,
    status_id bigint NOT NULL,
    employee_id bigint NOT NULL,
    type_transaction_id bigint NOT NULL,
    company_id bigint NOT NULL
);


ALTER TABLE public.settlements OWNER TO avtomatic_task;

--
-- Name: settlements_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.settlements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settlements_id_seq OWNER TO avtomatic_task;

--
-- Name: settlements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.settlements_id_seq OWNED BY public.settlements.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.statuses OWNER TO avtomatic_task;

--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statuses_id_seq OWNER TO avtomatic_task;

--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    date_create timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    date_finish timestamp(0) without time zone NOT NULL,
    priority_id bigint NOT NULL,
    executor_id bigint NOT NULL,
    author_id bigint NOT NULL,
    group_id bigint NOT NULL,
    status_id bigint NOT NULL
);


ALTER TABLE public.tasks OWNER TO avtomatic_task;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO avtomatic_task;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: teams; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.teams (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.teams OWNER TO avtomatic_task;

--
-- Name: teams_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teams_id_seq OWNER TO avtomatic_task;

--
-- Name: teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.teams_id_seq OWNED BY public.teams.id;


--
-- Name: type_transactions; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.type_transactions (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.type_transactions OWNER TO avtomatic_task;

--
-- Name: type_transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.type_transactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.type_transactions_id_seq OWNER TO avtomatic_task;

--
-- Name: type_transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.type_transactions_id_seq OWNED BY public.type_transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO avtomatic_task;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO avtomatic_task;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vacation_statuses; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.vacation_statuses (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.vacation_statuses OWNER TO avtomatic_task;

--
-- Name: vacation_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.vacation_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacation_statuses_id_seq OWNER TO avtomatic_task;

--
-- Name: vacation_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.vacation_statuses_id_seq OWNED BY public.vacation_statuses.id;


--
-- Name: vacations; Type: TABLE; Schema: public; Owner: avtomatic_task
--

CREATE TABLE public.vacations (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    date_start date NOT NULL,
    date_finish date NOT NULL,
    status_id bigint DEFAULT '1'::bigint NOT NULL,
    employee_id bigint NOT NULL
);


ALTER TABLE public.vacations OWNER TO avtomatic_task;

--
-- Name: vacations_id_seq; Type: SEQUENCE; Schema: public; Owner: avtomatic_task
--

CREATE SEQUENCE public.vacations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vacations_id_seq OWNER TO avtomatic_task;

--
-- Name: vacations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: avtomatic_task
--

ALTER SEQUENCE public.vacations_id_seq OWNED BY public.vacations.id;


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: employee_groups id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_groups ALTER COLUMN id SET DEFAULT nextval('public.employee_groups_id_seq'::regclass);


--
-- Name: employee_roles id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_roles ALTER COLUMN id SET DEFAULT nextval('public.employee_roles_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: entity_updates id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.entity_updates ALTER COLUMN id SET DEFAULT nextval('public.entity_updates_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: payment_statuses id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.payment_statuses ALTER COLUMN id SET DEFAULT nextval('public.payment_statuses_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: priorities id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.priorities ALTER COLUMN id SET DEFAULT nextval('public.priorities_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: settlements id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements ALTER COLUMN id SET DEFAULT nextval('public.settlements_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: teams id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.teams ALTER COLUMN id SET DEFAULT nextval('public.teams_id_seq'::regclass);


--
-- Name: type_transactions id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.type_transactions ALTER COLUMN id SET DEFAULT nextval('public.type_transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vacation_statuses id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacation_statuses ALTER COLUMN id SET DEFAULT nextval('public.vacation_statuses_id_seq'::regclass);


--
-- Name: vacations id; Type: DEFAULT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacations ALTER COLUMN id SET DEFAULT nextval('public.vacations_id_seq'::regclass);


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.cache (key, value, expiration) FROM stdin;
5c785c036466adea360111aa28563bfd556b5fba:timer	i:1757257919;	1757257919
5c785c036466adea360111aa28563bfd556b5fba	i:4;	1757257919
admin22@mail.com|127.0.0.1:timer	i:1757615429;	1757615429
admin22@mail.com|127.0.0.1	i:2;	1757615429
admin435@mail.com|127.0.0.1:timer	i:1759070226;	1759070226
admin435@mail.com|127.0.0.1	i:1;	1759070226
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.companies (id, name) FROM stdin;
2	ООО Транс строй
3	ЗАО БАМ
\.


--
-- Data for Name: employee_groups; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.employee_groups (id, employee_id, group_id) FROM stdin;
1	2	1
2	2	2
3	2	3
4	2	4
5	2	5
6	1	1
11	1	2
12	1	3
13	1	4
14	1	5
15	4	2
16	5	3
\.


--
-- Data for Name: employee_roles; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.employee_roles (id, role_id, employee_id, created_at, updated_at) FROM stdin;
1	1	2	\N	\N
2	1	1	\N	\N
3	2	4	\N	\N
4	2	5	\N	\N
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.employees (id, fio, email, password, age, sex, team_id, post_id, created_at, updated_at, email_verified_at, remember_token) FROM stdin;
2	Сертов Алексей Владимирович	admin225@mail.com	$2y$12$WBHw3EhUIN4VI4Xf5GsYQe4UyLRuVFy9nQNZoyXqub6JQFNsSfq0C	20	MALES	1	1	2025-08-31 12:09:37	2025-09-07 16:48:22	\N	\N
4	Колесников Дмитрий Олегович	admin223@mail.com	$2y$12$2PG5mOSs5NLWEOEhsh9GduMWAJ/e1iqpjulSlFYLy4ceWTIUkmZIe	24	MALES	1	1	2026-01-11 17:23:24	2026-01-11 17:24:40	\N	\N
5	Ипа Ипа Ипа	admin27@mail.com	$2y$12$.Jc5taJkTxkwhbJ/E8bTqusixwk2XiurGLyl/YQURSoQjQSk/b.Ua	24	MALES	1	1	2026-05-04 09:59:02	2026-05-04 09:59:22	\N	\N
1	Иванов Иван Натанович	admin221@mail.com	$2y$12$cZ/dv0e6TxT/EnKw6ji8Wuf6mR97ubJvKZ/Gn4JLXA3UuziThVRt.	20	MALES	1	1	2025-08-31 11:30:35	2025-09-07 16:48:57	\N	BcCvZ69wy7glXpmad2TcOcFVw8J1ftxwTOo6zraqKUvULUW7HMM1B4u4Gph2
\.


--
-- Data for Name: entity_updates; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.entity_updates (id, fio, name, created_at, updated_at, type, move) FROM stdin;
2	Иванов Иван Натанович	dsadasd123dsad`	2026-05-03 12:12:04	\N	Задача	Изменение
3	Иванов Иван Натанович	dsadasd123dsad`	2026-05-03 12:12:53	\N	Задача	Удаление
4	Иванов Иван Натанович	csac	2026-05-03 12:16:56	\N	Отпуск	Добавление
5	Иванов Иван Натанович	fdfssf	2026-05-03 13:16:54	\N	Задача	Добавление
6	Иванов Иван Натанович	testвфы	2026-05-03 13:27:40	\N	Отпуск	Добавление
7	Иванов Иван Натанович	testвфы	2026-05-03 13:31:05	\N	Отпуск	Изменение
8	Иванов Иван Натанович	testвфы	2026-05-03 13:38:16	\N	Отпуск	Изменение
9	Иванов Иван Натанович	testвфы	2026-05-03 16:27:06	\N	Отпуск	Изменение
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.groups (id, name) FROM stdin;
1	test
2	Первичая
3	Главная
4	Капсула
5	Сектор
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.migrations (id, migration, batch) FROM stdin;
29	0001_01_01_000000_create_users_table	1
30	0001_01_01_000001_create_cache_table	1
31	0001_01_01_000002_create_jobs_table	1
32	2024_07_10_102239_create_teams_table	1
33	2024_10_27_100525_create_personal_access_tokens_table	1
34	2025_05_16_191105_create_posts_table	1
35	2025_05_16_191157_create_roles_table	1
36	2025_05_16_191256_create_employees_table	1
37	2025_05_16_191921_create_statuses_table	1
38	2025_05_16_192015_create_groups_table	1
39	2025_05_16_192335_create_employee_groups_table	1
40	2025_05_16_192911_create_employee_roles_table	1
41	2025_05_17_164954_add_column_employees_table	1
42	2025_06_13_125736_create_priorities_table	1
43	2025_08_29_190703_create_tasks_table	1
44	2026_01_25_175128_create_companies_table	2
45	2026_01_25_175231_create_type_transactions_table	2
46	2026_01_25_175257_create_payment_statuses_table	2
47	2026_01_25_175328_create_vacation_statuses_table	2
48	2026_01_25_175431_create_vacations_table	2
51	2026_01_25_175511_create_settlements_table	3
52	2026_05_03_113613_create_entity_updates	4
53	2026_05_03_120412_add_column_entity_updates_table	5
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: payment_statuses; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.payment_statuses (id, name) FROM stdin;
2	оплачено
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.posts (id, name) FROM stdin;
1	менеджер
\.


--
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.priorities (id, name) FROM stdin;
1	первый
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.roles (id, name) FROM stdin;
1	admin
2	manager
3	super_manager
4	finance_manager
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
D0btvEhjaywu9A8sktxJGcOieucqGsxHxtv6U9vL	\N	127.0.0.1	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 YaBrowser/26.3.0.0 Safari/537.36	YTo2OntzOjY6Il90b2tlbiI7czo0MDoiRXllbFlBYzJMczlUYUphMk92NUlBOUVMU2hFeGNmSndnUGt5dTBqMSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mzc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9kYXNoYm9hcmQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjU1OiJsb2dpbl9iYWNrcGFja181OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7czoyMjoicGFzc3dvcmRfaGFzaF9iYWNrcGFjayI7czo2MDoiJDJ5JDEyJGNaL2R2MGU2VHhUL0VuS3c2amk4V3VmNm1SOTd1Ykp2S1ovR240SkxYQTNVdXppVGhWUnQuIjtzOjg6ImJhY2twYWNrIjthOjE6e3M6MTc6Imxhbmd1YWdlLXN3aXRjaGVyIjthOjE6e3M6NjoibG9jYWxlIjtzOjI6InJ1Ijt9fX0=	1777888868
\.


--
-- Data for Name: settlements; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.settlements (id, name, date_create, sum, status_id, employee_id, type_transaction_id, company_id) FROM stdin;
3	sdsdfc	2026-01-26 22:29:00	1000	2	2	3	2
4	dsad	2026-01-21 22:30:00	12000	2	2	2	2
5	dsadd	2026-01-30 22:30:00	1000000	2	2	2	3
6	dsadadfv	2026-01-22 22:31:00	12300	2	2	3	3
2	tes	2026-01-25 22:24:00	100000	2	2	3	2
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.statuses (id, name) FROM stdin;
1	создано
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.tasks (id, name, description, date_create, date_finish, priority_id, executor_id, author_id, group_id, status_id) FROM stdin;
2	Тест	sadxda	2025-08-31 15:52:00	2025-09-06 15:52:00	1	1	2	1	1
1	test	авыаыаыа	2025-08-31 15:11:00	2025-09-01 15:11:00	1	2	1	2	1
3	Интеграция системывыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыыссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссссс	тест	2025-09-07 19:49:00	2025-09-08 19:49:00	1	1	2	1	1
4	testмвы	васысм	2026-01-11 20:26:00	2026-01-17 20:26:00	1	2	4	3	1
5	dsadasd123	dsadasd	2026-05-03 14:50:00	2026-05-10 14:50:00	1	2	4	1	1
7	fdfssf	fdsfs	2026-05-03 15:49:00	2026-05-03 15:49:00	1	2	2	1	1
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.teams (id, name) FROM stdin;
1	главная
\.


--
-- Data for Name: type_transactions; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.type_transactions (id, name) FROM stdin;
2	поступление
3	отчисление
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vacation_statuses; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.vacation_statuses (id, name) FROM stdin;
2	на модерации
3	утвержден
\.


--
-- Data for Name: vacations; Type: TABLE DATA; Schema: public; Owner: avtomatic_task
--

COPY public.vacations (id, name, date_start, date_finish, status_id, employee_id) FROM stdin;
1	тест	2026-01-24	2026-01-28	3	2
4	csac	2026-05-03	2026-05-10	2	2
5	testвфы	2026-05-17	2026-05-30	2	2
\.


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.companies_id_seq', 3, true);


--
-- Name: employee_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.employee_groups_id_seq', 16, true);


--
-- Name: employee_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.employee_roles_id_seq', 4, true);


--
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.employees_id_seq', 5, true);


--
-- Name: entity_updates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.entity_updates_id_seq', 9, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.groups_id_seq', 5, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.migrations_id_seq', 53, true);


--
-- Name: payment_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.payment_statuses_id_seq', 2, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.posts_id_seq', 2, true);


--
-- Name: priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.priorities_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: settlements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.settlements_id_seq', 6, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.statuses_id_seq', 1, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.tasks_id_seq', 7, true);


--
-- Name: teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.teams_id_seq', 3, true);


--
-- Name: type_transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.type_transactions_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vacation_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.vacation_statuses_id_seq', 3, true);


--
-- Name: vacations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: avtomatic_task
--

SELECT pg_catalog.setval('public.vacations_id_seq', 5, true);


--
-- Name: cache_locks cache_locks_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT cache_locks_pkey PRIMARY KEY (key);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (key);


--
-- Name: companies companies_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_name_unique UNIQUE (name);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: employee_groups employee_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_groups
    ADD CONSTRAINT employee_groups_pkey PRIMARY KEY (id);


--
-- Name: employee_roles employee_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_roles
    ADD CONSTRAINT employee_roles_pkey PRIMARY KEY (id);


--
-- Name: employees employees_email_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_email_unique UNIQUE (email);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: entity_updates entity_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.entity_updates
    ADD CONSTRAINT entity_updates_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: groups groups_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_name_unique UNIQUE (name);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: job_batches job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT job_batches_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: payment_statuses payment_statuses_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_name_unique UNIQUE (name);


--
-- Name: payment_statuses payment_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: posts posts_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_name_unique UNIQUE (name);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: priorities priorities_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_name_unique UNIQUE (name);


--
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_unique UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settlements settlements_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_name_unique UNIQUE (name);


--
-- Name: settlements settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_name_unique UNIQUE (name);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: teams teams_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_name_unique UNIQUE (name);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: type_transactions type_transactions_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.type_transactions
    ADD CONSTRAINT type_transactions_name_unique UNIQUE (name);


--
-- Name: type_transactions type_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.type_transactions
    ADD CONSTRAINT type_transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vacation_statuses vacation_statuses_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacation_statuses
    ADD CONSTRAINT vacation_statuses_name_unique UNIQUE (name);


--
-- Name: vacation_statuses vacation_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacation_statuses
    ADD CONSTRAINT vacation_statuses_pkey PRIMARY KEY (id);


--
-- Name: vacations vacations_name_unique; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_name_unique UNIQUE (name);


--
-- Name: vacations vacations_pkey; Type: CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_pkey PRIMARY KEY (id);


--
-- Name: jobs_queue_index; Type: INDEX; Schema: public; Owner: avtomatic_task
--

CREATE INDEX jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: avtomatic_task
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: avtomatic_task
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: avtomatic_task
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: employee_groups employee_groups_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_groups
    ADD CONSTRAINT employee_groups_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_groups employee_groups_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_groups
    ADD CONSTRAINT employee_groups_group_id_foreign FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: employee_roles employee_roles_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_roles
    ADD CONSTRAINT employee_roles_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: employee_roles employee_roles_role_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employee_roles
    ADD CONSTRAINT employee_roles_role_id_foreign FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: employees employees_post_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_post_id_foreign FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: employees employees_team_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_team_id_foreign FOREIGN KEY (team_id) REFERENCES public.teams(id) ON DELETE CASCADE;


--
-- Name: settlements settlements_company_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_company_id_foreign FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: settlements settlements_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: settlements settlements_status_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_status_id_foreign FOREIGN KEY (status_id) REFERENCES public.payment_statuses(id) ON DELETE CASCADE;


--
-- Name: settlements settlements_type_transaction_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.settlements
    ADD CONSTRAINT settlements_type_transaction_id_foreign FOREIGN KEY (type_transaction_id) REFERENCES public.type_transactions(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_author_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_author_id_foreign FOREIGN KEY (author_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_executor_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_executor_id_foreign FOREIGN KEY (executor_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_group_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_group_id_foreign FOREIGN KEY (group_id) REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_priority_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_priority_id_foreign FOREIGN KEY (priority_id) REFERENCES public.priorities(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_status_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_status_id_foreign FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON DELETE CASCADE;


--
-- Name: vacations vacations_employee_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_employee_id_foreign FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- Name: vacations vacations_status_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: avtomatic_task
--

ALTER TABLE ONLY public.vacations
    ADD CONSTRAINT vacations_status_id_foreign FOREIGN KEY (status_id) REFERENCES public.vacation_statuses(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

